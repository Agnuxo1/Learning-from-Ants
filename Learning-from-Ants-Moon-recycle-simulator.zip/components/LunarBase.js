import React from 'react';

const LunarBase = ({ location }) => {

  return (
    <div className="lunar-base-container">
      <iframe
        src="https://eyes.nasa.gov/apps/solar-system/#/earth/moons/moon?interactPrompt=true&surfaceMapTiling=true&hd=true"
        title="NASA Eyes on the Solar System - Moon View"
        width="100%"
        height="100%"
        frameBorder="0"
        style={{ border: 'none' }}
        allowFullScreen
      />
    </div>
  );
};

export default LunarBase;

